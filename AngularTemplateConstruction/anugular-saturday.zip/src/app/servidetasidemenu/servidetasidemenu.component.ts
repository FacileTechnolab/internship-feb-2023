import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-servidetasidemenu',
  templateUrl: './servidetasidemenu.component.html',
  styleUrls: ['./servidetasidemenu.component.css']
})
export class ServidetasidemenuComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
