import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-statecounterbox',
  templateUrl: './statecounterbox.component.html',
  styleUrls: ['./statecounterbox.component.css']
})
export class StatecounterboxComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
