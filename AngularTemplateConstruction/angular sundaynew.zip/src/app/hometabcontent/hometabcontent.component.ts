import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hometabcontent',
  templateUrl: './hometabcontent.component.html',
  styleUrls: ['./hometabcontent.component.css']
})
export class HometabcontentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
